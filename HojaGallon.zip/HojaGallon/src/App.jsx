import './App.css';
import Encabezado from './components/Encabezado.jsx';
import Acerca from './components/acerca.jsx';
import Educacion from './Components/Educacion.jsx';
import Habilidades from './components/Habilidades.jsx';
import Referencias from './components/Referencias.jsx';

function App() {
  return (
    <div className="App">
      <Encabezado />
      <main className="container">
        <Acerca />
        <Experiencia />
        <Educacion />
        <Habilidades />
        <Referencias />
      </main>
    </div>
  )
}

export default App;
